#!/bin/bash
#sudo bash -c 'echo "auth,authpriv.* @@192.168.2.3:514" >> /etc/rsyslog.conf'
sudo apt update
sudo apt install git -y
#systemctl restart rsyslog
#systemctl restart rsyslog.service


# Check if "#welcome" is present in /etc/hostname, if not, append it
#sudo bash -c 'grep -q "#welcome" /etc/hostname || tee -a /etc/hostname <<< "#welcome"'





